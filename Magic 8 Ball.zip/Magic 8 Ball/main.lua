display.newImage("background.png", 160, 240)
display.newImage("octohedron.png", 160, 240)
local options = {
   text = "Hello World",
   x = 160,
   y = 260,
   fontSize = 10,
   width = 50,
   height = 40,
   align = "center"
}
 local textBox = display.newText( options )
display.newText("Shake device to activate.", 160, 50, "Comic Sans MS", 20)

local array = {
	"It is certain", "It is decidedly so", 
	"Without a doubt","Yes definitely",
	"You may rely on it","As I see it, yes",
	"Most likely"," Outlook good",
	"Yes","Signs point to yes",
	"Reply hazy try again","Ask again later",
	"Better not tell you now","Cannot predict now",
	"Concentrate and ask again","Don't count on it",
	"My reply is no","My sources say no",
	"Outlook not so good","Very doubtful"
}

function count(x)
	local thing = table.maxn(x)
	return thing
end

function triggered()
	local rand = math.random(1, count(array))
	local stuff = array[rand]
	textBox.text = stuff
end

Runtime:addEventListener( "accelerometer", triggered)
